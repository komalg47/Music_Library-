package com.contactmanager.servlet;

import com.contactmanager.model.Contact;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.IOException;

@WebServlet("/deleteContact")
public class DeleteContactServlet
        extends HttpServlet {

    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)

            throws ServletException,
            IOException {

        int id =
                Integer.parseInt(
                        request.getParameter("id"));

        AddContactServlet.contacts.removeIf(
                c -> c.getId() == id);

        request.setAttribute(
                "message",
                "Contact Deleted Successfully!");

        request.setAttribute(
                "contacts",
                AddContactServlet.contacts);

        request.getRequestDispatcher(
                "contacts.jsp")
                .forward(request,response);
    }
}