package com.contactmanager.servlet;

import com.contactmanager.model.Contact;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;

@WebServlet("/editContact")
public class EditContactServlet
        extends HttpServlet {

    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)

            throws ServletException,
            IOException {

        int id =
                Integer.parseInt(
                        request.getParameter("id"));

        for(Contact c :
                AddContactServlet.contacts){

            if(c.getId()==id){

                request.setAttribute(
                        "contact",
                        c);

                break;
            }
        }

        request.getRequestDispatcher(
                "editContact.jsp")
                .forward(request,response);
    }
}