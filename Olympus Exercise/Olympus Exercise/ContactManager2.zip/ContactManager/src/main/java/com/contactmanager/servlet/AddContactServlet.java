package com.contactmanager.servlet;

import com.contactmanager.model.Contact;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/addContact")
public class AddContactServlet extends HttpServlet {

    public static List<Contact> contacts =
            new ArrayList<>();

    private static int counter = 1;

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String name =
                request.getParameter("name");

        String phone =
                request.getParameter("phone");

        String email =
                request.getParameter("email");

        if(name.isEmpty()
                || phone.isEmpty()
                || email.isEmpty()) {

            request.setAttribute(
                    "error",
                    "All fields are mandatory!");

            request.getRequestDispatcher(
                    "addContact.jsp")
                    .forward(request,response);

            return;
        }

        Contact contact =
                new Contact(counter++,
                        name,
                        phone,
                        email);

        contacts.add(contact);

        request.setAttribute(
                "message",
                "Contact Added Successfully!");

        request.setAttribute(
                "contacts",
                contacts);

        request.getRequestDispatcher(
                "contacts.jsp")
                .forward(request,response);
    }
}