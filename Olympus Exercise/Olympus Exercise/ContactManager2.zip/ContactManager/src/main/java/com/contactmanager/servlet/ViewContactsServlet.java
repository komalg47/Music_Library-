package com.contactmanager.servlet;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;

@WebServlet("/viewContacts")
public class ViewContactsServlet
        extends HttpServlet {

    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)

            throws ServletException,
            IOException {

        request.setAttribute(
                "contacts",
                AddContactServlet.contacts);

        request.getRequestDispatcher(
                "contacts.jsp")
                .forward(request,response);
    }
}