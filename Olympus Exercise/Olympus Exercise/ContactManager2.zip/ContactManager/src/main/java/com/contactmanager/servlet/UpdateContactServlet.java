package com.contactmanager.servlet;

import com.contactmanager.model.Contact;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import java.io.IOException;

@WebServlet("/updateContact")
public class UpdateContactServlet
        extends HttpServlet {

    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)

            throws ServletException,
            IOException {

        int id =
                Integer.parseInt(
                        request.getParameter("id"));

        for(Contact c :
                AddContactServlet.contacts){

            if(c.getId()==id){

                c.setName(
                        request.getParameter("name"));

                c.setPhone(
                        request.getParameter("phone"));

                c.setEmail(
                        request.getParameter("email"));
            }
        }

        request.setAttribute(
                "message",
                "Contact Updated Successfully!");

        request.setAttribute(
                "contacts",
                AddContactServlet.contacts);

        request.getRequestDispatcher(
                "contacts.jsp")
                .forward(request,response);
    }
}