<html>
<head>

<title>Edit Contact</title>

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<h2>Edit Contact</h2>

<form action="updateContact"
method="post">

<input type="hidden"
name="id"
value="${contact.id}">

<input type="text"
name="name"
value="${contact.name}">

<input type="text"
name="phone"
value="${contact.phone}">

<input type="email"
name="email"
value="${contact.email}">

<button type="submit">
Update Contact
</button>

</form>

</body>
</html>