<html>
<head>
<title>Contact Manager</title>
</head>

<body>

<h1>Welcome To Contact Manager</h1>

<a href="addContact.jsp">
Add Contact
</a>

<br><br>

<a href="viewContacts">
View Contacts
</a>

</body>
</html>