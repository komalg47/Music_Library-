<%@ taglib uri=
"http://java.sun.com/jsp/jstl/core"
prefix="c"%>

<html>
<head>

<title>Contacts</title>

<link rel="stylesheet"
href="css/style.css">

</head>

<body>

<h2>My Contacts</h2>

<c:if test="${not empty message}">
<p class="success">
${message}
</p>
</c:if>

<table>

<tr>
<th>ID</th>
<th>Name</th>
<th>Phone</th>
<th>Email</th>
<th>Action</th>
</tr>

<c:forEach
var="c"
items="${contacts}">

<tr>

<td>${c.id}</td>
<td>${c.name}</td>
<td>${c.phone}</td>
<td>${c.email}</td>

<td>

<a href=
"editContact?id=${c.id}">
Edit
</a>

|

<a href=
"deleteContact?id=${c.id}">
Delete
</a>

</td>

</tr>

</c:forEach>

</table>

<br>

<a href="addContact.jsp">
Add New Contact
</a>

</body>
</html>