<%@ taglib uri="http://java.sun.com/jsp/jstl/core"
prefix="c"%>

<html>
<head>
<title>Add Contact</title>
<link rel="stylesheet"
href="css/style.css">
</head>

<body>

<h2>Add Contact</h2>

<c:if test="${not empty error}">
<p class="error">${error}</p>
</c:if>

<form action="addContact"
method="post">

<input type="text"
name="name"
placeholder="Name">

<input type="text"
name="phone"
placeholder="Phone">

<input type="email"
name="email"
placeholder="Email">

<button type="submit">
Add Contact
</button>

</form>

<a href="viewContacts">
View Contacts
</a>

</body>
</html>