package com.gl.handler;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.gl.model.Person;
import com.gl.repository.PersonRepository;

import reactor.core.publisher.Mono;

@Component
public class PersonHandler {

    private final PersonRepository personRepository;

    public PersonHandler(PersonRepository personRepository) {
        this.personRepository = personRepository;
    }

    public Mono<ServerResponse> getPerson(ServerRequest request) {

        String id = request.pathVariable("id");

        return personRepository.findById(id)
                .flatMap(person -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(person))
                .switchIfEmpty(ServerResponse.notFound().build());
    }

    public Mono<ServerResponse> getAllPersons(ServerRequest request) {

        return ServerResponse.ok()
                .contentType(MediaType.APPLICATION_JSON)
                .body(personRepository.findAll(), Person.class);
    }

    public Mono<ServerResponse> createPerson(ServerRequest request) {

        return request.bodyToMono(Person.class)
                .flatMap(personRepository::save)
                .flatMap(person -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(person));
    }

    public Mono<ServerResponse> updatePerson(ServerRequest request) {

        String id = request.pathVariable("id");

        return request.bodyToMono(Person.class)
                .flatMap(person -> personRepository.update(id, person))
                .flatMap(updatedPerson -> ServerResponse.ok()
                        .contentType(MediaType.APPLICATION_JSON)
                        .bodyValue(updatedPerson))
                .switchIfEmpty(ServerResponse.notFound().build());
    }

    public Mono<ServerResponse> deletePerson(ServerRequest request) {

        String id = request.pathVariable("id");

        return personRepository.delete(id)
                .then(ServerResponse.noContent().build());
    }
}