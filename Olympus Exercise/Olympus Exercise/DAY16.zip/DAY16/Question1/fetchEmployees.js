const apiUrl =
"https://dummy.restapiexample.com/api/v1/employees";

fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
        console.log("Employee Data:");
        console.log(data);
    })
    .catch(error => {
        console.error("Error:", error);
    });