function getUser() {

    fetch("https://randomuser.me/api/")
        .then(response => response.json())
        .then(data => {

            const user = data.results[0];

            document.getElementById("userInfo").innerHTML = `
                <h3>${user.name.first} ${user.name.last}</h3>
                <p>Email: ${user.email}</p>
                <img src="${user.picture.large}" alt="Profile">
            `;
        })
        .catch(error => {
            console.error("Error:", error);
        });
}