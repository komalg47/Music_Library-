Fetch API Project

Task 1:
- Fetch employee data from API
- Display in console

Task 2:
- Fetch random user data on button click
- Display name, email, and image on UI

Technologies Used:
- HTML
- CSS
- JavaScript (Fetch API)

How to Run:
1. Open index.html inside each folder
2. For Task 1 → open console (F12)
3. For Task 2 → click button to fetch user