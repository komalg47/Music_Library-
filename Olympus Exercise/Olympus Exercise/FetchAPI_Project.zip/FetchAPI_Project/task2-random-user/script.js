function getUser() {
    fetch("https://randomuser.me/api/")
    .then(response => response.json())
    .then(data => {

        let user = data.results[0];

        let output = `
            <div class="card">
                <img src="${user.picture.large}" />
                <h3>${user.name.first} ${user.name.last}</h3>
                <p>${user.email}</p>
            </div>
        `;

        document.getElementById("userData").innerHTML = output;
    })
    .catch(error => {
        console.log("Error:", error);
    });
}