package com.wipro.RestApiStudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
