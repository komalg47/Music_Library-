package com.example.StudentCrudDemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.StudentCrudDemo.entity.Student;
import com.example.StudentCrudDemo.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	StudentRepository repository;

	
	public Student addStudent(Student obj) {
		return repository.save(obj);
	}
	
	
	public Optional<Student> getStudent(int rollno)
	{
		return repository.findById(rollno);
	}
	
	public List<Student> getAllStudents()
	{
		return repository.findAll();
	}
	
	@Transactional
	public void deletStudent(String name)
	{
		repository.deleteByName(name);
	}

}
