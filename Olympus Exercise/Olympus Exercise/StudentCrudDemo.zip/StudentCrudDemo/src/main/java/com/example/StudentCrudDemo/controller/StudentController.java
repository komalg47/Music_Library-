package com.example.StudentCrudDemo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.StudentCrudDemo.entity.Student;
import com.example.StudentCrudDemo.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	StudentService service;
	
	
	@PostMapping("/add")
	public Student addStudent(@RequestBody Student obj) {
		return service.addStudent(obj);
	}
	
	
	

	@GetMapping("/student/{rollno}")
	public String getStudent(@PathVariable int rollno) {
		Optional<Student>  op= service.getStudent(rollno);
		if(op.isPresent())
			return "student found : "+op.get();
		else
			return "student not found!";
	}
	

	@GetMapping("/students")
	public List<Student> getStudents() {
		return  service.getAllStudents();
	}
	
	@DeleteMapping("/{name}")
	public String deleteStudent(@PathVariable String name) {
		service.deletStudent(name);
		return "student is deleted!";
	}
	
}
