package com.contactmanager.servlet;

import com.contactmanager.model.Contact;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addContact")
public class AddContactServlet extends HttpServlet {

    private static List<Contact> contacts = new ArrayList<>();

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");

        Contact contact =
                new Contact(name, phone, email);

        contacts.add(contact);

        request.setAttribute("contacts", contacts);

        request.getRequestDispatcher("contacts.jsp")
               .forward(request, response);
    }

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        request.setAttribute("contacts", contacts);

        request.getRequestDispatcher("contacts.jsp")
               .forward(request, response);
    }
}