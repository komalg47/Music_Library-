<%@ page import="java.util.*" %>
<%@ page import="com.contactmanager.model.Contact" %>

<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>All Contacts</title>

<link rel="stylesheet"
      href="css/style.css">

</head>

<body>

<div class="container">

<h2>My Contacts</h2>

<table>

<tr>
<th>Name</th>
<th>Phone</th>
<th>Email</th>
</tr>

<%

List<Contact> contacts =
(List<Contact>)request.getAttribute("contacts");

if(contacts != null){

for(Contact c : contacts){

%>

<tr>

<td><%= c.getName() %></td>

<td><%= c.getPhone() %></td>

<td><%= c.getEmail() %></td>

</tr>

<%
}
}
%>

</table>

<br>

<a href="addContact.jsp">

<button>Add More Contacts</button>

</a>

</div>

</body>
</html>