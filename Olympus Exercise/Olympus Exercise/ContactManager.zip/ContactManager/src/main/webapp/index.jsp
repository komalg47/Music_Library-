<!DOCTYPE html>
<html>
<head>

<meta charset="UTF-8">

<title>Contact Manager</title>

<link rel="stylesheet"
      href="css/style.css">

</head>

<body>

<div class="container">

<h1>Welcome To Contact Manager</h1>

<a href="addContact.jsp">

<button>Add Contact</button>

</a>

</div>

</body>
</html>