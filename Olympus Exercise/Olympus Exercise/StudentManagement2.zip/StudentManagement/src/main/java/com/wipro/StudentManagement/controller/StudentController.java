package com.wipro.StudentManagement.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class StudentController {

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/profile")
    public String profile(Model model) {

        model.addAttribute("name", "Priyanka");
        model.addAttribute("roll", "101");
        model.addAttribute("course", "Computer Science");
        model.addAttribute("email", "priyanka@gmail.com");

        return "profile";
    }

    @GetMapping("/timetable")
    public String timetable() {
        return "timetable";
    }
}